<?php
namespace App\Http\Controllers\Sheet;

use App\Http\Controllers\Controller;
use App\Models\Academic\Subject;
use App\Models\Sheet\Sheet;
use App\Models\Sheet\SheetPayment;
use App\Models\Sheet\SheetTopic;
use App\Models\Sheet\SheetTopicTaken;
use App\Models\Student\Student;
use Illuminate\Http\Request;

class SheetController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (! auth()->user()->can('sheets.view')) {
            return redirect()->back()->with('warning', 'No permission to view sheets.');
        }

        $sheets = Sheet::withCount([
            'sheetPayments as sheetPayments_count' => function ($query) {
                $query->whereHas('invoice.invoiceType', function ($q) {
                    $q->where('type_name', 'Sheet Fee');
                });
            },
        ])
            ->with(['sheetPayments.invoice.paymentTransactions'])
            ->withWhereHas('class', function ($query) {
                $query->active();
            })
            ->latest('id')
            ->get();

        // Calculate total revenue from all sheet payments
        $totalRevenue = $sheets->sum(function ($sheet) {
            return $sheet->sheetPayments->sum(function ($payment) {
                return $payment->invoice?->paymentTransactions->sum('amount_paid') ?? 0;
            });
        });

        // Prepare JSON data for JavaScript
        $sheetsJson = $sheets->map(function ($sheet) {
            return [
                'id'           => $sheet->id,
                'className'    => $sheet->class->name,
                'classNumeral' => $sheet->class->class_numeral,
                'price'        => $sheet->price,
                'salesCount'   => $sheet->sheetPayments_count,
                'createdAt'    => $sheet->created_at?->format('Y-m-d') ?? now()->format('Y-m-d'),
            ];
        });

        return view('sheets.index', compact('sheets', 'sheetsJson', 'totalRevenue'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return redirect()->route('sheets.index');
    }

    /**
     * Store a newly created resource in storage.
     * Note: Sheets are created automatically when a class is created.
     */
    public function store(Request $request)
    {
        return redirect()->route('sheets.index')->with('warning', 'Sheets are created automatically with classes.');
    }

    /**
     * Display the specified sheet.
     */
    public function show(string $id)
    {
        if (auth()->user()->cannot('sheets.view')) {
            return redirect()->back()->with('warning', 'No permission to view sheets.');
        }

        // Eager load all necessary relationships
        $sheet = Sheet::with(['class.subjects.sheetTopics.sheetsTaken', 'sheetPayments.invoice.paymentTransactions', 'sheetPayments.student'])->find($id);

        if (! $sheet) {
            return redirect()->route('sheets.index')->with('warning', 'Sheet group not found.');
        }

        // Calculate statistics
        $subjects = $sheet->class->subjects;
        $stats    = [
            'totalNotes'        => $subjects->sum(fn($s) => $s->sheetTopics->count()),
            'activeNotes'       => $subjects->sum(fn($s) => $s->sheetTopics->where('status', 'active')->count()),
            'inactiveNotes'     => $subjects->sum(fn($s) => $s->sheetTopics->where('status', 'inactive')->count()),
            'subjectsWithNotes' => $subjects->filter(fn($s) => $s->sheetTopics->isNotEmpty())->count(),
            'totalRevenue'      => $sheet->sheetPayments->sum(fn($payment) => $payment->invoice?->paymentTransactions->sum('amount_paid') ?? 0),
            'totalDue'          => $sheet->sheetPayments->sum(fn($payment) => $payment->invoice->amount_due ?? 0),
            'totalSales'        => $sheet->sheetPayments->count(),
        ];

        return view('sheets.view', compact('sheet', 'stats'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return redirect()->back()->with('warning', 'URL Not Allowed');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (! auth()->user()->can('sheets.edit')) {
            return response()->json([
                'success' => false,
                'message' => 'No permission to edit sheets.',
            ], 403);
        }

        $validated = $request->validate([
            'sheet_price_edit' => 'required|numeric|min:100',
        ]);

        $sheet = Sheet::findOrFail($id);
        $sheet->update([
            'price' => $validated['sheet_price_edit'],
        ]);

        // Return JSON response
        return response()->json([
            'success' => true,
            'message' => 'Sheet group updated successfully.',
            'data'    => $sheet,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        return redirect()->back()->with('warning', 'URL Not Allowed');
    }

    /**
     * Get sheets data as JSON for AJAX requests.
     */
    public function getData()
    {
        if (! auth()->user()->can('sheets.view')) {
            return response()->json([
                'success' => false,
                'message' => 'No permission to view sheets.',
            ], 403);
        }

        $sheets = Sheet::withCount([
            'sheetPayments as sheetPayments_count' => function ($query) {
                $query->whereHas('invoice.invoiceType', function ($q) {
                    $q->where('type_name', 'Sheet Fee');
                });
            },
        ])
            ->withWhereHas('class', function ($query) {
                $query->active();
            })
            ->latest('id')
            ->get()
            ->map(function ($sheet) {
                return [
                    'id'           => $sheet->id,
                    'className'    => $sheet->class->name,
                    'classNumeral' => $sheet->class->class_numeral,
                    'price'        => $sheet->price,
                    'salesCount'   => $sheet->sheetPayments_count,
                    'createdAt'    => $sheet->created_at?->format('Y-m-d') ?? now()->format('Y-m-d'),
                ];
            });

        return response()->json([
            'success' => true,
            'data'    => $sheets,
        ]);
    }

    public function getPaidSheets($studentId)
    {
        $payments = SheetPayment::with('sheet')->where('student_id', $studentId)->whereHas('invoice', fn($q) => $q->whereIn('status', ['paid', 'partially_paid'])->whereHas('invoiceType', fn($i) => $i->where('type_name', 'Sheet Fee')))->get();

        $sheets = $payments->map(function ($payment) {
            return [
                'id'             => $payment->sheet_id,
                'name'           => $payment->sheet->class->name ?? 'Unknown Sheet',
                'payment_status' => $payment->invoice->status ?? 'unknown',
            ];
        });

        return response()->json(['sheets' => $sheets]);
    }

    public function getSheetTopics(Sheet $sheet, $studentId)
    {
        $student = Student::with('class')->findOrFail($studentId);

        // Debugging - uncomment if needed
        // \Log::debug("Student Data", [
        //     'class_numeral'  => $student->class->class_numeral,
        //     'academic_group' => $student->academic_group,
        // ]);

        $subjects = Subject::where('class_id', $sheet->class_id)
            ->where(function ($query) use ($student) {
                $query->where('academic_group', 'General');

                if (in_array($student->class->class_numeral, ['09', '10', '11', '12'])) {
                    $query->orWhere('academic_group', $student->academic_group);
                }
            })
            ->get();

        // Debug subjects query
        // \Log::debug("Subjects Query Results", $subjects->toArray());

        $topics = SheetTopic::whereIn('subject_id', $subjects->pluck('id'))->with('subject')->get();

        $distributedTopics = SheetTopicTaken::where('student_id', $studentId)->whereIn('sheet_topic_id', $topics->pluck('id'))->pluck('sheet_topic_id')->toArray();

        return response()->json([
            'topics'            => $topics,
            'distributedTopics' => $distributedTopics,
            'studentGroup'      => $student->academic_group,
            'classNumeral'      => $student->class->class_numeral,
            'debug'             => [
                // Temporary debug info
                'student_group'    => $student->academic_group,
                'class_numeral'    => $student->class->class_numeral,
                'subject_count'    => $subjects->count(),
                'science_subjects' => $subjects->where('academic_group', 'Science')->count(),
            ],
        ]);
    }

    /* --- Added After 01.01.2026 12.45 AM --- */
    /**
     * Get all subjects for a sheet group
     * Used in index page filter dropdown
     *
     * @param Sheet $sheet
     * @return \Illuminate\Http\JsonResponse
     */
    public function getSubjectsList(Sheet $sheet)
    {
        $subjects = Subject::where('class_id', $sheet->class_id)->orderBy('academic_group')->orderBy('name')->get();

        $formattedSubjects = $subjects->map(function ($subject) {
            return [
                'id'             => $subject->id,
                'name'           => $subject->name,
                'academic_group' => $subject->academic_group ?? 'General',
            ];
        });

        return response()->json([
            'success'  => true,
            'subjects' => $formattedSubjects,
            'sheet'    => [
                'id'         => $sheet->id,
                'class_name' => $sheet->class->name ?? 'Unknown',
            ],
        ]);
    }

    /**
     * Get topics for a specific subject within a sheet group
     * Used in index page filter dropdown (after subject selection)
     *
     * @param Sheet $sheet
     * @param Subject $subject
     * @return \Illuminate\Http\JsonResponse
     */
    public function getSubjectTopics(Sheet $sheet, Subject $subject)
    {
        // Verify subject belongs to this sheet's class
        if ($subject->class_id !== $sheet->class_id) {
            return response()->json(
                [
                    'success' => false,
                    'message' => 'Subject does not belong to this sheet group',
                ],
                400,
            );
        }

        $topics = SheetTopic::where('subject_id', $subject->id)->where('status', 'active')->orderBy('topic_name')->get();

        $formattedTopics = $topics->map(function ($topic) {
            return [
                'id'     => $topic->id,
                'name'   => $topic->topic_name,
                'status' => $topic->status,
            ];
        });

        return response()->json([
            'success' => true,
            'topics'  => $formattedTopics,
            'subject' => [
                'id'   => $subject->id,
                'name' => $subject->name,
            ],
        ]);
    }

    /**
     * Get all topics for a sheet group
     * Used in bulk distribution dropdown
     *
     * @param Sheet $sheet
     * @return \Illuminate\Http\JsonResponse
     */
    public function getTopicsList(Sheet $sheet)
    {
        // Get all subjects for this sheet's class
        $subjects = Subject::where('class_id', $sheet->class_id)->get();

        // Get all active topics for these subjects
        $topics = SheetTopic::whereIn('subject_id', $subjects->pluck('id'))->where('status', 'active')->with('subject:id,name,academic_group')->orderBy('subject_id')->orderBy('topic_name')->get();

        $formattedTopics = $topics->map(function ($topic) {
            return [
                'id'             => $topic->id,
                'name'           => $topic->topic_name,
                'subject'        => $topic->subject->name ?? 'Unknown',
                'academic_group' => $topic->subject->academic_group ?? 'General',
                'status'         => $topic->status,
            ];
        });

        return response()->json([
            'success' => true,
            'topics'  => $formattedTopics,
            'sheet'   => [
                'id'         => $sheet->id,
                'class_name' => $sheet->class->name ?? 'Unknown',
            ],
        ]);
    }

    /**
     * Get students who paid for sheet but haven't received specific topic
     * Used in bulk distribution
     *
     * @param Sheet $sheet
     * @param SheetTopic $topic
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPendingStudents(Sheet $sheet, SheetTopic $topic)
    {
        $branchId = auth()->user()->branch_id;

        // Get all students who paid for this sheet
        $paidPayments = SheetPayment::where('sheet_id', $sheet->id)
            ->whereHas('invoice', function ($query) {
                $query->whereIn('status', ['paid', 'partially_paid'])->whereHas('invoiceType', function ($q) {
                    $q->where('type_name', 'Sheet Fee');
                });
            })
            ->whereHas('student', function ($query) {
                $query->active();
            })
            ->with(['student:id,name,student_unique_id,class_id,academic_group,branch_id', 'student.class:id,name,class_numeral'])
            ->when($branchId != 0, function ($query) use ($branchId) {
                $query->whereHas('student', function ($q) use ($branchId) {
                    $q->where('branch_id', $branchId);
                });
            })
            ->get();

        // Get students who already have this topic with distribution details
        $distributedRecords = SheetTopicTaken::where('sheet_topic_id', $topic->id)
            ->with(['student:id,name,student_unique_id', 'distributedBy:id,name'])
            ->get();

        $distributedStudentIds = $distributedRecords->pluck('student_id')->toArray();

        // Get topic's academic group
        $topicSubject       = Subject::find($topic->subject_id);
        $topicAcademicGroup = $topicSubject->academic_group ?? 'General';

        // Filter students
        $pendingStudents         = [];
        $alreadyDistributedCount = 0;
        $totalPaidCount          = $paidPayments->count();

        foreach ($paidPayments as $payment) {
            $student = $payment->student;

            if (! $student) {
                continue;
            }

            // Check if already distributed
            if (in_array($student->id, $distributedStudentIds)) {
                $alreadyDistributedCount++;
                continue;
            }

            // Check academic group compatibility
            // General topics are available to all students
            // Group-specific topics are only for students in that group
            if ($topicAcademicGroup !== 'General') {
                $classNumeral = $student->class->class_numeral ?? '';

                // Only check academic group for classes 09, 10, 11, 12
                if (in_array($classNumeral, ['09', '10', '11', '12'])) {
                    if ($student->academic_group !== $topicAcademicGroup) {
                        continue; // Skip students from different academic groups
                    }
                }
            }

            $pendingStudents[] = [
                'id'                => $student->id,
                'name'              => $student->name,
                'student_unique_id' => $student->student_unique_id,
                'class_name'        => $student->class->name ?? 'N/A',
                'academic_group'    => $student->academic_group ?? 'General',
            ];
        }

        // Format distributed students for response
        $distributedStudents = $distributedRecords
            ->map(function ($record) {
                return [
                    'id'                  => $record->student->id ?? null,
                    'name'                => $record->student->name ?? 'Unknown',
                    'student_unique_id'   => $record->student->student_unique_id ?? 'N/A',
                    'distributed_at'      => $record->created_at->toISOString(),
                    'distributed_by_name' => $record->distributedBy->name ?? 'System',
                ];
            })
            ->values()
            ->toArray();

        return response()->json([
            'success'              => true,
            'students'             => $pendingStudents,
            'distributed_students' => $distributedStudents,
            'stats'                => [
                'total_paid'          => $totalPaidCount,
                'already_distributed' => $alreadyDistributedCount,
                'pending'             => count($pendingStudents),
            ],
            'topic'                => [
                'id'             => $topic->id,
                'name'           => $topic->topic_name,
                'subject'        => $topicSubject->name ?? 'Unknown',
                'academic_group' => $topicAcademicGroup,
            ],
            'sheet'                => [
                'id'         => $sheet->id,
                'class_name' => $sheet->class->name ?? 'Unknown',
            ],
        ]);
    }
    /* --- Till Now --- */
}
