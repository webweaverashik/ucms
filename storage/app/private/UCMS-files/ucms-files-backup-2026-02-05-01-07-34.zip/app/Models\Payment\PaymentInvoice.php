<?php
namespace App\Models\Payment;

use App\Models\User;
use App\Models\Student\Student;
use App\Models\Sheet\SheetPayment;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PaymentInvoice extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'invoice_number',
        'student_id',
        'total_amount',
        'amount_due',
        'month_year',
        'status',
        'invoice_type_id',
        'created_by',
        'deleted_by',
    ];

    public function invoiceType()
    {
        return $this->belongsTo(PaymentInvoiceType::class, 'invoice_type_id');
    }

    public function student()
    {
        return $this->belongsTo(Student::class)->withTrashed();
    }

    public function paymentTransactions()
    {
        return $this->hasMany(PaymentTransaction::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by')->withTrashed();
    }

    // Check if the student has an associated sheet
    public function hasSheet()
    {
        return $this->sheetPayment && $this->sheetPayment->sheet;
    }

    /*
        Get all the sheet payments for this invoice
    */
    public function sheetPayment()
    {
        return $this->hasOne(SheetPayment::class, 'invoice_id');
    }

    /*
    * Get secondary class payments
    */
    public function secondaryClassPayments()
    {
        return $this->hasOne(SecondaryClassPayment::class, 'invoice_id');
    }

    public function isSpecialClassFee(): bool
    {
        return $this->invoiceType?->type_name === 'Special Class Fee';
    }

    /**
     * Invoice comments
     */
    public function comments(): HasMany
    {
        return $this->hasMany(PaymentInvoiceComment::class);
    }
}
