<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('teachers', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('phone', 11);
            $table->string('email')->unique();
            $table->string('password');
            $table->string('photo_url')->nullable();
            $table->integer('base_salary');
            $table->boolean('is_active')->default(true);
            $table->enum('gender', ['male', 'female']);
            $table->text('academic_qualification')->nullable();
            $table->string('experience')->nullable();
            $table->string('blood_group')->nullable();
            $table->softDeletes();
            $table->foreignId('deleted_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('teachers');
    }
};
